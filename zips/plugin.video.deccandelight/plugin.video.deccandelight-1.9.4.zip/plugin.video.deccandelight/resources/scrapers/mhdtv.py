"""
mhdtvlive deccandelight plugin
Copyright (C) 2016 Gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
"""
from _base_ import Scraper
from BeautifulSoup import BeautifulSoup, SoupStrainer
import urllib
import re
import requests
import time
from resources.lib import cfscrape
import xbmc
import xbmcgui
import HTMLParser
import json

try:
    import StorageServer
except:
    import storageserverdummy as StorageServer
cache = StorageServer.StorageServer('deccandelight', 1)


class mhdtv(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'http://mhdtvworld.live/'
        self.icon = self.ipath + 'mhdtv.png'
        self.list = {'01Tamil TV': 'tamilMMMM5',
                     '02Telugu TV': self.bu + 'tv-channels/telugu-channels/',
                     '03Malayalam TV': 'malayalamMMMM5',
                     '04Kannada TV': self.bu + 'tv-channels/kannada-channels/',
                     '05Hindi TV': 'hindiMMMM5',
                     '06English TV': 'englishMMMM5',
                     '07Sports TV': self.bu + 'tv-channels/sports-channels/',
                     '08Marathi TV': self.bu + 'tv-channels/marathi-channels/',
                     '09Punjabi TV': self.bu + 'tv-channels/punjabi-channels/',
                     '10Bangla TV': self.bu + 'tv-channels/bangla-channels/'}

    def get_login(self):
        usr = self.settings('mhdusr')
        pwd = self.settings('mhdpwd')
        durl = self.bu + 'wp-includes/js/wp-embed.min.js'
        lurl = self.bu + 'wp-login.php'
        cj = cfscrape.get_tokens(durl, user_agent=self.hdr['User-Agent'])[0]
        if len(usr) < 1 or len(pwd) < 1:
            xbmcgui.Dialog().ok('MHDTV Settings', 'Setup Username and Password in Settings!')
            self.list = {}
            return
        data = {'log': usr,
                'pwd': pwd,
                'wp-submit': 'Log In',
                'redirect_to': self.bu,
                'action': 'vt_ajax_login',
                'button_label': 'Log In'}
        resp = requests.post(lurl, data=data, headers=self.hdr, cookies=cj, allow_redirects=False)
        lcj = requests.utils.dict_from_cookiejar(resp.cookies)
        try:
            if len(cj['cf_clearance']) > 0:
                lcj['cf_clearance'] = cj['cf_clearance']
        except:
            pass
        ckstr = '; '.join([str(x) + "=" + str(y) for x, y in lcj.items()])
        return (lcj, ckstr)

    def get_menu(self):
        return (self.list, 7, self.icon)

    def get_second(self, iurl):
        """
        Get the list of dates.
        :return: list
        """
        cats = {'tamil': {'01Entertainment': self.bu + 'tv-channels/tamil-entertainment/',
                          '02Local': self.bu + 'tv-channels/tamil-local-web/',
                          '03News': self.bu + 'tv-channels/tamil-news/'},
                'malayalam': {'01Entertainment': self.bu + 'tv-channels/malayalam-entertainment/',
                              '02Local': self.bu + 'tv-channels/malayalam-local-web/',
                              '03News': self.bu + 'tv-channels/malayalam-news/',
                              '04Devotional': self.bu + 'tv-channels/malayalam-devotional/'},
                'hindi': {'01Entertainment': self.bu + 'tv-channels/hindi-channels/',
                          '02Movies': self.bu + 'tv-channels/hindi-movies/',
                          '03Music': self.bu + 'tv-channels/hindi-music/',
                          '04News': self.bu + 'tv-channels/hindi-news/',
                          '05Devotional': self.bu + 'tv-channels/hindi-devotional/'},
                'english': {'01Entertainment': self.bu + 'tv-channels/english-channels/',
                            '03News': self.bu + 'tv-channels/english-news/'}}

        categories = []

        for title, url in sorted(cats[iurl].iteritems()):
            categories.append((title[2:], self.icon, url))

        return (categories, 7)

    def get_items(self, iurl):
        cj, ckstr = cache.cacheFunction(self.get_login)
        channels = []
        h = HTMLParser.HTMLParser()
        mlink = SoupStrainer('article', {'class': 'item'})
        plink = SoupStrainer('div', {'class': 'resppages'})
        nextpg = True
        while nextpg:
            html = requests.get(iurl, cookies=cj, headers=self.hdr).text
            Paginator = BeautifulSoup(html, parseOnlyThese=plink)
            items = BeautifulSoup(html, parseOnlyThese=mlink)
            for item in items:
                title = h.unescape(item.h3.text).encode('utf8')
                url = item.find('a')['href']
                thumb = item.find('img')['src'] + '|User-Agent=%s&Cookie=%s' % (self.hdr['User-Agent'], ckstr)
                channels.append((title.title(), thumb, url))
            if 'chevron-right' in str(Paginator):
                iurl = Paginator.find('a')['href']
            else:
                nextpg = False
        return (sorted(channels), 9)

    def get_video(self, url):
        cj, ckstr = cache.cacheFunction(self.get_login)
        ajaxurl = self.bu + 'wp-admin/admin-ajax.php'
        html = requests.get(url, cookies=cj, headers=self.hdr).text
        matches = re.findall(r'''li\s*id=["']player-option-\d["'].+?post=["']([^"']+).+?nume=["']([^"']+).+?title'>([^<]+)''', html)
        if len(matches) > 0:
            if len(matches)>1:
                sources = []
                for match in matches:
                    sources.append(match[2])
                dialog = xbmcgui.Dialog()
                ret = dialog.select('Choose a Source', sources)
                match = matches[ret]
            else:
                match = matches[0]
            headers = self.hdr
            headers['Referer'] = url
            data = {'action': 'doo_player_ajax',
                    'post': match[0],
                    'nume': match[1],
                    'type': 'movie'}
            ahtml = requests.post(ajaxurl, data=data, cookies=cj, headers=headers).text
            aurl = re.findall("<iframe.+?src='([^']+)",ahtml)[0]
            if not aurl.startswith('http'):
                aurl = self.bu[:-1] + aurl
            if 'youtube.com' in aurl:
                return aurl
            jhtml = requests.get(aurl, cookies=cj, headers=headers).text
            if 'Clappr.Player' in jhtml:
                stream_url = re.findall(r'source:\s*"([^"]+)',jhtml)[0]
            elif 'var jw =' in jhtml:
                jdata = json.loads(re.findall(r'var\s*jw\s*=\s*([^<]+)',jhtml)[0])
                stream_url = jdata['file']
            elif 'sources: [' in jhtml:
                stream_url = re.findall(r'file:\s*"([^"]+)',jhtml)[0]
                if not stream_url.startswith('http'):
                    stream_url = 'http:' + stream_url
            elif 'var url=' in jhtml:
                stream_url = re.findall(r'var\s*url\s*=\s*"([^"]+)',jhtml)[0]
                stream_url = re.findall('(http.+/)',aurl)[0] + stream_url
            elif 'playerInstance.setup(' in jhtml:
                stream_url = re.findall(r'file:\s*"([^"]+)',jhtml)[0]
            else:
                self.log('%s not resolvable.\n' % url)
                stream_url = 'http://content.jwplatform.com/videos/7RtXk3vl-52qL9xLP.mp4'
        else:
            self.log('%s not resolvable.\n' % url)
            stream_url = 'http://content.jwplatform.com/videos/7RtXk3vl-52qL9xLP.mp4'
        
        stream_url += '|User-Agent={}'.format(self.hdr['User-Agent'])
        if stream_url.startswith(self.bu):
            stream_url += '&Referer={}&Cookie={}'.format(self.bu,ckstr)
        # self.log('Stream_url is %s\n'%stream_url)
        return stream_url
