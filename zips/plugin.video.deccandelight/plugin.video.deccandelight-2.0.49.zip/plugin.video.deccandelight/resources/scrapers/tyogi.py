'''
DeccanDelight scraper plugin
Copyright (C) 2016 gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
import json
import re

from bs4 import BeautifulSoup, SoupStrainer
from resources.lib import control, client
from resources.lib.base import Scraper
from six.moves import urllib_parse


class tyogi(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'https://tamilyogi.blog/'
        self.icon = self.ipath + 'tyogi.png'

    def get_menu(self):
        html = client.request(self.bu)
        items = {}
        cats = re.findall(r'''<strong><a\s*href="([^"]+)">([^<]+)''', html, re.DOTALL)
        sno = 1
        for cat, title in cats:
            cat = urllib_parse.urljoin(self.bu, cat)
            items['%02d' % sno + title] = cat
            sno += 1
        items['%02d' % sno + '[COLOR yellow]** Search **[/COLOR]'] = self.bu + '?s='
        return (items, 7, self.icon)

    def get_items(self, url):
        movies = []
        if url[-3:] == '?s=':
            search_text = self.get_SearchQuery('Tamil Yogi')
            search_text = urllib_parse.quote_plus(search_text)
            url = url + search_text

        nmode = 8 if '-series/' in url else 9
        html = client.request(url)
        mlink = SoupStrainer('main', {'id': 'primary'})
        mdiv = BeautifulSoup(html, "html.parser", parse_only=mlink)
        plink = SoupStrainer('nav', {'class': re.compile('pagination$')})
        Paginator = BeautifulSoup(html, "html.parser", parse_only=plink)
        items = mdiv.find_all('article')

        for item in items:
            title = self.unescape(item.find('h2').text)
            if ')' in title:
                title = title.split(')')[0] + ')'
            url = item.find('h2').a.get('href')
            thumb = item.find('img').get('src')
            cpath = urllib_parse.urlparse(thumb).netloc
            if control.pathExists(control.TRANSLATEPATH(control._ppath) + cpath + '.json'):
                cfhdrs = json.loads(client.retrieve(cpath + '.json'))
                thumb += '|{0}'.format(urllib_parse.urlencode(cfhdrs))
            movies.append((title, thumb, url))

        if "next page-numbers" in str(Paginator):
            pages = Paginator.find_all('a', {'class': re.compile('page-numbers')})
            last_pg = pages[-2].text.strip()
            curr_pg = Paginator.find('span', {'class': 'current'}).text.strip()
            purl = pages[-1].get('href')
            title = 'Next Page.. (Currently in Page {0} of {1})'.format(curr_pg, last_pg)
            movies.append((title, self.nicon, purl))

        return (movies, nmode)

    def get_videos(self, url):
        videos = []

        html = client.request(url, headers=self.hdr)
        mlink = SoupStrainer('div', {'class': 'entry-content'})
        videoclass = BeautifulSoup(html, "html.parser", parse_only=mlink)
        links = videoclass.find_all('p')

        try:
            for link in links:
                vidurl = link.find('a').get('href')
                if 'tamilvip.' in vidurl:
                    vidurl = 'https://vidplay.one/xembed-' + vidurl.split('?')[-1]
                vidtxt = self.unescape(link.text)
                self.resolve_media(vidurl, videos, vidtxt=vidtxt)
        except:
            pass

        try:
            for link in links:
                vidurl = link.find('iframe').get('src')
                title = self.unescape(videoclass.find('h1').text)
                if ')' in title:
                    title = title.split(')')[0] + ')'
                self.resolve_media(vidurl, videos, vidtxt=title)
        except:
            pass

        return videos

    def get_video(self, url):
        html = client.request(url, referer=self.bu)
        mlink = SoupStrainer('div', {'class': 'entry-content'})
        mdiv = BeautifulSoup(html, "html.parser", parse_only=mlink)
        eurl = mdiv.find('iframe').get('src')
        if self.hmf(eurl):
            return eurl

        self.log('{0} not resolvable {1}.\n'.format(url, eurl), 'info')
        return
