'''
Sominal deccandelight plugin
Copyright (C) 2019 Gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
from _base_ import Scraper
from BeautifulSoup import BeautifulSoup, SoupStrainer
import urllib, re, requests, random
import HTMLParser
import xbmcgui

class sominal(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'https://www.playsominaltv.com/language/'
        self.icon = self.ipath + 'sominal.png'
        self.hdstr = self.settings('sominalhd')
        self.list = {'01Tamil Movies': self.bu + 'tamil/',
                     '02Telugu Movies': self.bu + 'telugu/',
                     '03Malayalam Movies': self.bu + 'malayalam/',
                     '04Kannada Movies': self.bu + 'kannada/',
                     '05Hindi Movies': self.bu + 'hindi/',
                     '06Bengali Movies': self.bu + 'bengali/',
                     '07Punjabi Movies': self.bu + 'punjabi/',
                     '08Marathi Movies': self.bu + 'marathi/',
                     '09Gujarati Movies': self.bu + 'gujarati/',
                     '99[COLOR yellow]** Search **[/COLOR]': self.bu[:-9] + '?s='}
                    
    def get_menu(self):
        return (self.list,7,self.icon)
    
    def get_items(self,url):
        h = HTMLParser.HTMLParser()
        movies = []
        if url[-3:] == '?s=':
            search_text = self.get_SearchQuery('Sominal')
            search_text = urllib.quote_plus(search_text)
            url = url + search_text

        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('article')
        items = BeautifulSoup(html, parseOnlyThese=mlink)
        plink = SoupStrainer('div', {'class': 'pagination'})
        Paginator = BeautifulSoup(html, parseOnlyThese=plink)
        
        for item in items:
            title = h.unescape(item.find('div', {'class': 'title'}).text)
            title = self.clean_title(title)
            url = item.find('a')['href']
            try:
                thumb = item.find('img')['src']
            except:
                thumb = self.icon
            movies.append((title, thumb, url))
        
        if 'nextpagination' in str(Paginator):
            nextli = Paginator.findAll('a', {'class': 'arrow_pag'})
            purl = nextli[-1].get('href')
            pgtxt = Paginator.span.text
            title = 'Next Page.. (Currently in {ptxt})'.format(ptxt=pgtxt)
            movies.append((title, self.nicon, purl))
        
        return (movies,9)

    def get_video(self,url):
        apihosts = ['zagent1249', 'zagent1934', 'zagent1606']
        apiurl = 'https://{host}.h-cdn.com/cmd/get_links_info?customer=playsom&zone=gen&ver=1.148.429&url={url}'
        sreq = {"url": "https://www.playsominaltv.com/requests/",
                "type": "page", "size": "30x20",
                "description": "Request Movies"}
        headers = self.hdr
        headers.update({'Referer': url, 'Origin': 'https://www.playsominaltv.com'})
        jdata = {"items": [{"url": url, "type": "page", "size": "32x22", "nat_size": "22x22"},
                           sreq]}
        req = False
        while not req:
            r = requests.post(apiurl.format(host=random.choice(apihosts) , url=urllib.quote_plus(url)), headers=headers, json=jdata)
            if r.status_code == requests.codes.ok:
                req = True
        sdata = r.json()
        try:
            strurl = sdata[url]['full_video_url']
        except KeyError:
            strurl = ''
            xbmcgui.Dialog().notification('Sominal', 'Video not yet available!', self.icon, 5000, False)
        
        if 'SD.mp4' in strurl and self.hdstr == 'true':
            r = requests.head(strurl.replace('SD.mp4', 'HD.mp4'), headers=headers)
            if r.status_code == requests.codes.ok:
                strurl = strurl.replace('SD.mp4', 'HD.mp4')
        elif 'HD.mp4' in strurl and self.hdstr == 'false':
            r = requests.head(strurl.replace('HD.mp4', 'SD.mp4'), headers=headers)
            if r.status_code == requests.codes.ok:
                strurl = strurl.replace('HD.mp4', 'SD.mp4')
        return strurl
