'''
GeoTV DeccanDelight plugin
Copyright (C) 2017 gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
from _base_ import Scraper
from BeautifulSoup import BeautifulSoup, SoupStrainer
import re, requests
import HTMLParser

class geo(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'http://harpalgeo.tv/'
        self.icon = self.ipath + 'geo.png'
        self.list = {'01Dramas': self.bu + 'programs/'}

    def get_menu(self):
        return (self.list,5,self.icon)

    def get_second(self, iurl):
        """
        Get the list of shows.
        """
        shows = []
        h = HTMLParser.HTMLParser()

        html = requests.get(iurl, headers=self.hdr).text
        mlink = SoupStrainer('div', {'class': 'row'})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        plink = SoupStrainer('div', {'class': 'pagination'})
        Paginator = BeautifulSoup(html, parseOnlyThese=plink)
        items = mdiv.findAll('div', {'class': 'cat_inr_placement'})
        for item in items:
            title = h.unescape(item.h4.text).encode('utf8')
            url = item.find('a')['href']
            try:
                thumb = item.find('img')['src']
            except:
                thumb = self.icon
            shows.append((title, thumb, url))

        if 'next' in str(Paginator):
            purl = Paginator.find('a', {'rel': 'next'}).get('href')
            currpg = Paginator.find('strong').text
            lastpg = Paginator.findAll('a')[-1].get('data-ci-pagination-page')
            title = 'Next Page.. (Currently in Page {0} of {1})'.format(currpg, lastpg)
            shows.append((title, self.nicon, purl))
        return (shows,7)

    def get_items(self,url):
        h = HTMLParser.HTMLParser()
        movies = []

        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('div', {'class': 'programVideos'})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        nurl = self.bu + 'program/more_videos/{}'
        nextpg = True
        page = 1
        catid = re.findall(r'id="category_id"\s*value="([^"]+)', html)[0]
        data = {'category_id': catid}
        headers = self.hdr
        headers.update({'Referer': self.bu,
                        'X-Requested-With': 'XMLHttpRequest'})
        while nextpg:
            items = mdiv.findAll('div', {'class': re.compile('^col-lg-2')})
            for item in items:
                title = h.unescape(item.findAll('p')[-1].text).encode('utf8')
                if 'teaser' not in title.lower() and 'promo' not in title.lower():
                    title = title.split('|')[0]
                    title = title.replace('Har Pal Geo','').replace('Dramas','')
                    url = item.find('a')['href']
                    try:
                        thumb = item.find('img')['src']
                    except:
                        thumb = self.icon
                    movies.append((title, thumb, url))
            page += 1
            html = requests.post(nurl.format(page), headers=headers, data=data).text
            if len(html) > 0:
                mdiv = BeautifulSoup(html)
            else:
                nextpg = False
        return (movies,9)

    def get_video(self,url):
        html = requests.get(url, headers=self.hdr).text
        eurl = re.findall(r"hls:\s*'([^']+)", html)[0]
        return eurl
