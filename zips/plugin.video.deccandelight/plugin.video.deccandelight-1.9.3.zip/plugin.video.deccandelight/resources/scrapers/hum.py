'''
HumTV DeccanDelight plugin
Copyright (C) 2017 gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
from _base_ import Scraper
from BeautifulSoup import BeautifulSoup, SoupStrainer
import re
import requests
import HTMLParser
import xbmcgui


class hum(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'https://www.hum.tv/'
        self.icon = self.ipath + 'hum.png'
        self.list = {'01Dramas': self.bu + 'dramas/MMMM5',
                     '02Telefilms': self.bu + 'telefilms/'}

    def get_menu(self):
        return (self.list, 7, self.icon)

    def get_second(self, iurl):
        """
        Get the list of shows.
        """
        shows = []
        h = HTMLParser.HTMLParser()

        html = requests.get(iurl, headers=self.hdr).text
        mlink = SoupStrainer('div', {'class': 'container'})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        plink = SoupStrainer('div', {'class': 'wp-pagenavi'})
        Paginator = BeautifulSoup(html, parseOnlyThese=plink)
        items = mdiv.findAll('article')
        for item in items:
            title = h.unescape(item.text)
            url = item.find('a')['href'] + '/episodes/'
            try:
                thumb = item.find('img')['data-lazy-src']
            except:
                thumb = self.icon
            shows.append((title, thumb, url))

        if 'next' in str(Paginator):
            purl = Paginator.find('a', {'class': re.compile('^next')}).get('href')
            currpg = Paginator.find('span', {'class': re.compile('current$')}).text
            lastpg = Paginator.findAll('a', {'class': 'page-numbers'})[-1].text
            title = 'Next Page.. (Currently in Page {0} of {1})'.format(currpg, lastpg)
            shows.append((title, self.nicon, purl))
        return (shows, 7)

    def get_items(self, url):
        h = HTMLParser.HTMLParser()
        movies = []

        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('div', {'class': 'container'})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        plink = SoupStrainer('div', {'class': 'wp-pagenavi'})
        Paginator = BeautifulSoup(html, parseOnlyThese=plink)
        items = mdiv.findAll('article')

        for item in items:
            if 'googletag' not in str(item):
                try:
                    title = h.unescape(item.h4.text).encode('utf8')
                except:
                    title = h.unescape(item.text).encode('utf8')
                url = item.find('a')['href']
                try:
                    thumb = item.find('img')['data-lazy-src']
                except:
                    thumb = self.icon
                movies.append((title, thumb, url))

        if 'next' in str(Paginator):
            purl = Paginator.find('a', {'class': re.compile('^next')}).get('href')
            currpg = Paginator.find('span', {'class': re.compile('current$')}).text
            lastpg = Paginator.findAll('a', {'class': 'page-numbers'})[-1].text
            title = 'Next Page.. (Currently in Page {0} of {1})'.format(currpg, lastpg)
            movies.append((title, self.nicon, purl))

        return (movies, 9)

    def get_video(self, url):
        videos = []
        sources = []
        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('iframe')
        items = BeautifulSoup(html, parseOnlyThese=mlink)
        for item in items:
            vidurl = item.get('src')
            vidhost = self.get_vidhost(vidurl)
            sources.append(vidhost)
            videos.append(vidurl)
        eurl = videos[0]
        if len(sources) > 1:
            dialog = xbmcgui.Dialog()
            ret = dialog.select('Choose a Source', sources)
            eurl = videos[ret]
        return eurl
