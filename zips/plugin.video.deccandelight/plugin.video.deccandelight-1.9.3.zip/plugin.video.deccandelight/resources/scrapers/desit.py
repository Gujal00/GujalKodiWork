"""
desitashan deccandelight plugin
Copyright (C) 2016 Gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
"""
from _base_ import Scraper
from BeautifulSoup import BeautifulSoup, SoupStrainer
import urllib
import re
import requests
import HTMLParser
import xbmcgui


class desit(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'http://www.desitellybox.me/'
        self.icon = self.ipath + 'desit.png'
            
    def get_menu(self):
        html = requests.get(self.bu, headers=self.hdr).text
        mlink = SoupStrainer('ul', {'rel': 'Main Menu'})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        items = mdiv.findAll('li')
        list = {}
        ino = 1
        for item in items:
            list['{:02d}{}'.format(ino, item.text)] = item.find('a')['href']
            ino += 1
        list['99[COLOR yellow]** Search **[/COLOR]'] = self.bu + '?s=MMMM7'
        return list, 5, self.icon

    def get_second(self, iurl):
        """
        Get the list of shows.
        """
        shows = []
        h = HTMLParser.HTMLParser()

        html = requests.get(iurl, headers=self.hdr).text
        mlink = SoupStrainer('div', {'class': 'entry_content'})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        items = mdiv.findAll('li')
        thumb = mdiv.find('img')['src']
        if thumb.startswith('/'):
            thumb = self.bu[:-1] + thumb
        for item in items:
            if 'children' not in str(item):
                title = h.unescape(item.text)
                url = item.find('a')['href']
                shows.append((title, thumb, url))

        return shows, 7
        
    def get_items(self, iurl):
        episodes = []
        h = HTMLParser.HTMLParser()
        if iurl[-3:] == '?s=':
            search_text = self.get_SearchQuery('Desi Tashan')
            search_text = urllib.quote_plus(search_text)
            iurl += search_text
        nextpg = True
        while nextpg and len(episodes) < 21:
            html = requests.get(iurl).text
            mlink = SoupStrainer('div', {'class': 'col col_12_of_12'})
            mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
            items = mdiv.findAll('div', {'class': 'item_content'})
            for item in items:
                title = h.unescape(item.h4.text)
                if 'watch online' in title.lower():
                    title = self.clean_title(title)
                    url = item.find('a')['href']
                    try:
                        icon = item.find('img')['src']
                    except:
                        icon = self.icon           
                    episodes.append((title, icon, url))
                    
            plink = SoupStrainer('ul', {'class': 'page-numbers'})
            Paginator = BeautifulSoup(html, parseOnlyThese=plink)

            if 'next' in str(Paginator):
                iurl = Paginator.find('a', {'class': re.compile('^next')}).get('href')
                if len(episodes) > 20:
                    currpg = Paginator.find('span', {'class': re.compile('current$')}).text
                    lastpg = Paginator.findAll('a', {'class': 'page-numbers'})[-1].text
                    title = 'Next Page.. (Currently in Page {0} of {1})'.format(currpg, lastpg)
                    episodes.append((title, self.nicon, iurl))
            else:
                nextpg = False
        return episodes, 8

    def get_videos(self, iurl):
        videos = []
        h = HTMLParser.HTMLParser()
        html = requests.get(iurl).text
        mlink = SoupStrainer('div', {'class': 'entry_content'})
        videoclass = BeautifulSoup(html, parseOnlyThese=mlink)
        items = videoclass.findAll('a', {'class': None})
        if len(items) < 1:
            items = videoclass.findAll('a', {'class': re.compile('nofollow')})
        prog_per = 0
        numlink = 0
        p_dialog = xbmcgui.DialogProgress()
        p_dialog.create('Deccan Delight', 'Collecting Links...')
        for item in items:
            vid_link = item['href']
            vidtxt = h.unescape(item.text)
            try:
                vidtxt = re.findall(r'(Part\s*\d*)', vidtxt)[0]
            except:
                vidtxt = ''
            self.resolve_media(vid_link, videos, vidtxt)
            prog_per += 100/len(items)
            numlink += 1
            if p_dialog.iscanceled():
                return videos
            p_dialog.update(prog_per, 'Collected Links... {} of {}'.format(numlink, len(items)))
        return videos
