'''
bolly2tolly deccandelight plugin
Copyright (C) 2019 Gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
from _base_ import Scraper
from BeautifulSoup import BeautifulSoup, SoupStrainer
import urllib, re, requests, json, HTMLParser
from resources.lib import jsunpack

class b2t(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'https://www.bolly2tolly.net/category/'
        self.icon = self.ipath + 'b2t.png'
        self.list = {'01Tamil Movies': self.bu + 'tamil-hd-7',
                     '02Telugu Movies': self.bu + 'telugu-hd-010',
                     '03Malayalam Movies': self.bu + 'malayalam-04',
                     '04Kannada Movies': self.bu + 'kannada',
                     '11Hindi Movies': self.bu + 'hindi-3',
                     '21English Movies': self.bu + 'english',
                     '34Bengali Movies': self.bu + 'bengali',
                     '99[COLOR yellow]** Search **[/COLOR]': self.bu[:-9] + '?s='}
                    
    def get_menu(self):
        return (self.list,7,self.icon)
    
    def get_items(self,url):
        h = HTMLParser.HTMLParser()
        movies = []
        if url[-3:] == '?s=':
            search_text = self.get_SearchQuery('Bolly2Tolly')
            search_text = urllib.quote_plus(search_text)
            url = url + search_text

        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('article')
        items = BeautifulSoup(html, parseOnlyThese=mlink)
        plink = SoupStrainer('div', {'class': 'wp-pagenavi'})
        Paginator = BeautifulSoup(html, parseOnlyThese=plink)
        
        for item in items:
            title = h.unescape(item.h3.text)
            title = self.clean_title(title)
            url = item.a.get('href')
            try:
                thumb = item.find('img')['src'].replace('-185x275','')
            except:
                thumb = self.icon
            movies.append((title, thumb, url))
        
        if 'Next' in str(Paginator):
            purl = Paginator.find('a', {'class': re.compile('^next')}).get('href')
            currpg = Paginator.find('span').text
            lastpg = Paginator.findAll('a', {'class':'page-numbers'})[-1].text
            title = 'Next Page.. (Currently in Page {0} of {1})'.format(currpg, lastpg)
            movies.append((title, self.nicon, purl))
        
        return (movies,8)

    def get_videos(self,url):
        h = HTMLParser.HTMLParser()
        videos = []
            
        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('div', {'class': 'TPlayer'})
        videoclass = BeautifulSoup(html, parseOnlyThese=mlink)

        try:
            links = videoclass.findAll('div', {'class': re.compile('^TPlayerTb')})
            for link in links:
                content = h.unescape(link.contents[0])
                if type(content) is unicode:
                    link = BeautifulSoup(content)
                vidurl = link.find('iframe')['src']
                self.resolve_media(vidurl,videos)
        except:
            pass
            
        return videos
