'''
thiruttuvcd deccandelight plugin
Copyright (C) 2016 Gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
from _base_ import Scraper
from BeautifulSoup import BeautifulSoup, SoupStrainer
import urllib, re, requests
import HTMLParser

class tvcd(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'https://www.thiruttuvcd.stream/genre/'
        self.icon = self.ipath + 'tvcd.png'
        self.list = {'01Tamil Movies': self.bu + 'tamil-movies/',
                     '02Telugu Movies': self.bu + 'telugu-movies/',
                     '03Malayalam Movies': self.bu + 'malayalam-movies/',
                     '05Hindi Movies': self.bu + 'bollywood-movies/',
                     '99[COLOR yellow]** Search **[/COLOR]': self.bu[:-6] + '?s='}
    
    def get_menu(self):
        return (self.list,7,self.icon)
    
    def get_items(self,url):
        h = HTMLParser.HTMLParser()
        movies = []
        if url[-3:] == '?s=':
            search_text = self.get_SearchQuery('Thiruttu VCD')
            search_text = urllib.quote_plus(search_text)
            url = url + search_text

        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('div', {'class':re.compile('^movies-list ')})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        plink = SoupStrainer('ul', {'class': 'pagination'})
        Paginator = BeautifulSoup(html, parseOnlyThese=plink)
        items = mdiv.findAll('div', {'class': 'ml-item'})
        
        for item in items:
            title = h.unescape(item.find('h2').text)
            title = self.clean_title(title)
            url = item.find('a')['href']
            tdiv = item.find('img')
            if 'src=' in str(tdiv):
                thumb = tdiv.get('src').encode('utf8')
            elif 'data-original=' in str(tdiv):
                thumb = tdiv.get('data-original').encode('utf8')
            else:
                thumb = self.icon
            movies.append((title, thumb, url))
        
        r = re.search(r'<link\s*rel="next"\s*href="([^"]+)', html)
        if r:
            purl = r.group(1)
            currpg = Paginator.find('li', {'class': 'active'}).text
            lastpg = Paginator.findAll('a', {'rel': 'nofollow'})[-1].get('href').split('/')[-2]
            title = 'Next Page.. (Currently in Page {0} of {1})'.format(currpg, lastpg)
            movies.append((title, self.nicon, purl))
        
        return (movies,8)

    def get_videos(self,url):
        videos = []
            
        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('ul', {'class': 'tab-content'})
        videoclass = BeautifulSoup(html, parseOnlyThese=mlink)
              
        try:
            links = videoclass.findAll('iframe')
            for link in links:
                vidurl = link.get('src')
                self.resolve_media(vidurl,videos)
        except:
            pass
            
        return videos
