"""
    SonyLIV Kodi Addon
    Copyright (C) 2018 gujal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import sys
from urlparse import parse_qsl
import xbmc
import xbmcvfs
import xbmcgui
import xbmcplugin
import xbmcaddon
import re 
import requests
import urllib
import time
import StringIO

try:
    import StorageServer
except:
    import storageserverdummy as StorageServer

# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

_addon = xbmcaddon.Addon()
_addonname = _addon.getAddonInfo('name')
_version = _addon.getAddonInfo('version')
_addonID = _addon.getAddonInfo('id')
_icon = _addon.getAddonInfo('icon')
_fanart = _addon.getAddonInfo('fanart')
_settings = _addon.getSetting

cache = StorageServer.StorageServer('sonyliv', _settings('timeout'))

def clear_cache():
    """
    Clear the cache database.
    """
    msg = 'Cached Data has been cleared'
    cache.table_name = 'sonyliv'
    cache.cacheDelete('%get%')
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(_addonname, msg, 3000, _icon))

safhdr = 'Mozilla/5.0 (%s) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A356 Safari/604.1'

try:
    platform = re.findall(r'\(([^\)]+)', xbmc.getUserAgent())[0]
except:
    platform = 'Linux; Android 4.4.4; MI 5 Build/KTU84P'

if _settings('version') != _version:
    _addon.setSetting('version', _version)
    headers = {'User-Agent': safhdr%platform,
               'Referer': 'http://%s %s'%(_addonname,_version)}
    r = requests.get('\x68\x74\x74\x70\x3a\x2f\x2f\x67\x6f\x6f\x2e\x67\x6c\x2f\x62\x34\x6e\x58\x32\x6d',headers=headers)
    clear_cache()
    _addon.openSettings()


apiUrl = 'https://www.sonyliv.com/api/v4/vod/search'
headers = {'User-Agent': 'okhttp/3.4.1'}

quals = ['SD','HD']
qual = quals[int(_settings('quality'))]
subtitles = True if _settings('subs') == 'true' else False

def get_pk():
    """
    Get the policy key.
    :return: string
    """
    url = 'https://players.brightcove.net/5182475815001/S1XJ5Tfez_default/index.min.js?_=%s'%int(time.time()*1000)
    html = requests.get(url, headers=headers).content
    pk = re.findall(r'policyKey:\s*"([^"]+)',html)[0]
    return pk


def get_bands():
    """
    Get the show bands.
    :return: json
    """
    url = 'https://www.sonyliv.com/api/configuration/asset_band_details'
    jdata = requests.get(url, headers=headers).json()
    return jdata


def get_srt(vttfile):
    content = requests.get(vttfile,headers=headers).content
    replacement = re.sub(r'([\d]+)\.([\d]+)', r'\1,\2', content)
    replacement = re.sub(r'WEBVTT\n\n', '', replacement)
    replacement = re.sub(r'^\d+\n', '', replacement)
    replacement = re.sub(r'\n\d+\n', '\n', replacement)
    replacement = StringIO.StringIO(replacement)
    idx = 1
    content = ''
    for line in replacement:
        if '-->' in line:
            if len(line.split(' --> ')[0]) < 12:
                line = re.sub(r'([\d]+):([\d]+),([\d]+)', r'00:\1:\2,\3', line)
            content += '%s\n%s'%(idx,line) 
            idx += 1
        else:
            content += line
    f = xbmcvfs.File('special://temp/TemporarySubs.en.srt','w')
    result = f.write(content)
    f.close()
    return 'special://temp/TemporarySubs.en.srt'


def get_top():
    """
    Get the list of countries.
    :return: list
    """
    MAINLIST = ['Channels', 'Movies', 'Clear Cache']
    return MAINLIST


def get_genres():
    """
    Get the list of channels.
    :return: list
    """
    channels = []
    url = 'https://www.sonyliv.com/api/configuration/initial/config'
    jd = requests.get(url,headers=headers).json()
    cnav = jd[0]['config_nav'][0]['items']
    for cn in cnav:
        if cn['id'] == 'MOVIES':
            items = cn['items']
    bands = jd[0]['config_bands']
    for item in items:
        gid = item['action'].split('/')[-1]
        if 'all' not in gid:
            for band in bands:
                if band['id'] == gid:
                    sdata = urllib.quote_plus(band['data'])
                    stype = band['type']
                    title = band['title']
                    sort = urllib.quote_plus(band['sort'])
                    channels.append((title,gid,sdata,stype,sort))
                    break
    
    return channels


def get_showdata(show,title):
    """
    Get the list of channels.
    :return: list
    """
    jd = cache.cacheFunction(get_bands)
    bands = jd['asset_band_details'][1]['bands']
    #xbmc.log('@@@@Show title = %s'%title,xbmc.LOGNOTICE)
    sdata = 'exact=true&all=type:Episodes&all=showname:%s'%show
    stype = 'search'
    id = 'Episodes'
    sort = 'START_DATE:DESC'
    for band in bands:
        if band['title'].lower() == title:
            sdata = band['data']
            stype = band['type']
            id = band['id']
            sort = band['sort']
            break
    
    return (sdata,stype,id,sort)

    
def get_channels():
    """
    Get the list of channels.
    :return: list
    """
    channels = []
    url = 'https://www.sonyliv.com/api/configuration/initial/config'
    jd = requests.get(url,headers=headers).json()
    cnav = jd[0]['config_nav'][0]['items']
    for cn in cnav:
        if cn['id'] == 'TV_SHOWS':
            items = cn['items']
    bands = jd[0]['config_bands']
    for item in items:
        cid = item['action'].split('/')[-1]
        if 'all' not in cid:
            for band in bands:
                if band['id'] == cid.lower() or band['id'] == cid.lower() + '_shows':
                    sdata = urllib.quote_plus(band['data'])
                    stype = band['type']
                    title = band['title']
                    sort = band['sort'] if len(band['sort'])>1 else 'START_DATE:DESC'
                    channels.append((title,cid,sdata,stype,urllib.quote_plus(sort)))
                    break
    
    return channels


def get_shows(cid,sdata,stype,sort):
    """
    Get the list of shows.
    :return: list
    """
    shows = []
    nextpg = True
    page = 0
    while nextpg:
        itemsused = 0 if page < 1 else 15
        cpage = 0 if page < 2 else page - 1
        data = {'detailsType':'basic',
                'searchSet':[{'sortOrder':urllib.unquote_plus(sort),
                              'data':urllib.unquote_plus(sdata),
                              'type':stype,
                              'id':cid,
                              'itemsUsed':itemsused,
                              'pageSize':15,
                              'pageNumber':cpage}],
                'deviceDetails':{'mfg':'WEB',
                                 'os':'others',
                                 'osVer':'XXX',
                                 'model':'WEB',
                                 'deviceId':96316679821,
                                 'platform':'web'},
                'isSearchable':True}         
        jd = requests.post(apiUrl, json=data, headers=headers).json()
        items = jd[0]['assets']
        for item in items:
            title = item['title']
            try:
                sname = item['showname']
            except KeyError:
                sname = title.lower().replace(' ','')
            labels = {'title': title,
                      'genre': item['genre'],
                      'plot': item['shortDesc'],
                      'mediatype': 'tvshow'
                     }
            fanart = item['assetLandscapeImage']
            if not fanart:
                fanart = item['tvBackgroundImage']
            if not fanart:
                fanart = item['thumbnailUrl']
            try:
                thumb = item['posterUrl']
            except:
                thumb = item['thumbnailUrl']
            icon = {'poster': item['thumbnailUrl'],
                   'icon': thumb,
                   'thumb': thumb,
                   'fanart': fanart}
            try:
                labels['premiered'] = item['releaseDate']
            except:
                pass
            shows.append((title,icon,sname,labels))
        if len(items) > 0:
            page += 1
        else:
            nextpg = False
    
    return shows
    

def get_movies(gid,sdata,stype,sort,page):
    """
    Get the list of movies.
    :return: list
    """
    movies = []
    page = int(page)
    itemsused = 0 if page < 1 else 15
    cpage = 0 if page < 2 else page - 1
    data = {'detailsType':'basic',
            'searchSet':[{'sortOrder':urllib.unquote_plus(sort),
                          'data':urllib.unquote_plus(sdata),
                          'type':stype,
                          'id':gid,
                          'itemsUsed':itemsused,
                          'pageSize':15,
                          'pageNumber':cpage}],
            'deviceDetails':{'mfg':'WEB',
                             'os':'others',
                             'osVer':'XXX',
                             'model':'WEB',
                             'deviceId':96316679821,
                             'platform':'web'},
            'isSearchable':True}
        
    jd = requests.post(apiUrl, json=data, headers=headers).json()        
    items = jd[0]['assets']
    for item in items:
        title = item['title']
        iurl = item['id']
        labels = {'title': title,
                  'genre': item['genre'],
                  'plot': item['shortDesc'],
                  'duration': item['duration']/1000,
                  'mediatype': 'movie'
                 }
        try:
            poster = item['posterUrl']
        except KeyError:
            poster = ''
        fanart = item['assetLandscapeImage']
        if not fanart:
            fanart = poster

        icon = {'poster': item['thumbnailUrl'],
               'icon': poster,
               'thumb': poster,
               'fanart': fanart}
        try:
            labels['year'] = item['releaseDate']
        except KeyError:
            pass
        movies.append((title,icon,iurl,labels))
    
    if len(items) > 10:
        page += 1
        title = 'Next Page... (Currently in Page %s)'%page
        labels = {}
        icon = {'poster': _icon,
               'icon': _icon,
               'thumb': _icon,
               'fanart': _fanart}
        movies.append((title,icon,page,labels))
    
    return movies


def get_episodes(show,title,page):
    """
    Get the list of episodes.
    :return: list
    """
    episodes = []
    page = int(page)
    itemsused = 0 if page < 1 else 15
    cpage = 0 if page < 2 else page - 1
    show = urllib.unquote_plus(show)
    title = urllib.unquote_plus(title)
    sdata,stype,id,sort = get_showdata(show,title)
    data = {'detailsType':'basic',
            'searchSet':[{'sortOrder':sort,
                          #'sortOrder':'START_DATE:DESC',
                          #'data':'exact=true&all=type:Episodes&all=showname:%s'%show,
                          'data':sdata,
                          'type':stype,
                          #'type':'search',
                          #'id':'Episodes',
                          'id':id,
                          'itemsUsed':itemsused,
                          'pageSize':15,
                          'pageNumber':cpage}],
            'deviceDetails':{'mfg':'WEB',
                             'os':'others',
                             'osVer':'XXX',
                             'model':'WEB',
                             'deviceId':96316679821,
                             'platform':'web'},
            'isSearchable':True}
    tries = 3
    items = [] 
    while tries > 0 and len(items) < 1:
        jd = requests.post(apiUrl, json=data, headers=headers).json()        
        items = jd[0]['assets']
        tries -= 1
        if len(items) < 1:
            xbmc.sleep(3000)
    for item in items:
        parts = item['title'].split(' - ')
        etitle = ''
        for part in parts:
            if show not in part.lower():
                r = re.search(r'\d{4}',part)
                if not r:
                    etitle += part + ' '
        if len(etitle) < 4:
            etitle = item['title']
        iurl = item['id']
        try:
            duration = item['duration']/1000
        except KeyError:
            duration = 0
        labels = {'title': etitle,
                  'genre': item['genre'],
                  'plot': item['shortDesc'],
                  'duration': duration,
                  'episode': item['episode'],
                  'tvshowtitle': title,
                  'mediatype': 'episode'
                 }
        fanart = item['assetLandscapeImage']
        if not fanart:
            fanart = item['tvBackgroundImage']
        if not fanart:
            fanart = item['thumbnailUrl']
        try:
            thumb = item['posterUrl']
        except:
            thumb = item['thumbnailUrl']
        icon = {'poster': item['thumbnailUrl'],
               'icon': thumb,
               'thumb': thumb,
               'fanart': fanart}
        try:
            labels['premiered'] = item['releaseDate']
        except:
            pass
        episodes.append((etitle,icon,iurl,labels))
    
    if len(items) > 0:
        page += 1
        etitle = 'Next Page... (Currently in Page %s)'%page
        labels = {}
        icon = {'poster': _icon,
               'icon': _icon,
               'thumb': _icon,
               'fanart': fanart}
        episodes.append((etitle,icon,page,labels))
            
    return episodes


def list_top():
    """
    Create the list of countries in the Kodi interface.
    """
    items = get_top()
    listing = []
    for item in items:
        list_item = xbmcgui.ListItem(label=item)
        list_item.setInfo('video', {'title': item, 'genre': item})
        list_item.setProperty('IsPlayable', 'false')
        list_item.setArt({'poster': _icon,
                          'icon': _icon,
                          'thumb': _icon,
                          'fanart': _fanart})
        url = '{0}?action=list_item&item={1}'.format(_url, item)
        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.setContent(_handle, 'addons')
    xbmcplugin.endOfDirectory(_handle)


def list_genres():
    """
    Create the list of countries in the Kodi interface.
    """
    langs = cache.cacheFunction(get_genres)
    listing = []
    for title,gid,sdata,stype,sort in langs:
        list_item = xbmcgui.ListItem(label='[COLOR yellow]%s[/COLOR]'%(title))
        list_item.setInfo('video', {'title': title, 'genre': title})
        list_item.setProperty('IsPlayable', 'false')
        list_item.setArt({'poster': _icon,
                          'icon': _icon,
                          'thumb': _icon,
                          'fanart': _fanart})
        url = '{0}?action=list_movies&gid={1}&sdata={2}&stype={3}&sort={4}&page=0'.format(_url, gid, sdata, stype, sort)
        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.setContent(_handle, 'addons')
    xbmcplugin.endOfDirectory(_handle)


def list_channels():
    """
    Create the list of countries in the Kodi interface.
    """
    channels = cache.cacheFunction(get_channels)
    listing = []
    for title,cid,sdata,stype,sort in channels:
        list_item = xbmcgui.ListItem(label='[COLOR yellow]%s[/COLOR]'%title)
        list_item.setProperty('IsPlayable', 'false')
        list_item.setArt({'poster': _icon,
                          'icon': _icon,
                          'thumb': _icon,
                          'fanart': _fanart})
        list_item.setInfo('video', {'title': title})
        url = '{0}?action=list_shows&cid={1}&sdata={2}&stype={3}&sort={4}'.format(_url, cid, sdata, stype, sort)
        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.setContent(_handle, 'addons')
    xbmcplugin.endOfDirectory(_handle)


def list_shows(cid,sdata,stype,sort):
    """
    Create the list of channels in the Kodi interface.
    """
    shows = cache.cacheFunction(get_shows,cid,sdata,stype,sort)
    listing = []
    for title,icon,sname,labels in shows:
        list_item = xbmcgui.ListItem(label='[COLOR yellow]%s[/COLOR]'%title)
        list_item.setArt(icon)
        list_item.setInfo('video', labels)
        list_item.setProperty('IsPlayable', 'false')
        # xbmc.log('Adding SName {} - Title {}'.format(sname,title), xbmc.LOGNOTICE)
        if not sname:
            sname = title.lower().replace(' ','')
        url = '{0}?action=list_episodes&show={1}&title={1}&page=0'.format(_url,urllib.quote_plus(sname),urllib.quote_plus(title))
        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.setContent(_handle, 'tvshows')
    xbmcplugin.endOfDirectory(_handle)


def list_movies(gid,sdata,stype,sort,page):
    """
    Create the list of episodes in the Kodi interface.
    """
    movies = cache.cacheFunction(get_movies,gid,sdata,stype,sort,page)
    listing = []
    for title,icon,iurl,labels in movies:
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt(icon)
        list_item.setInfo('video', labels)
        if 'Next Page' in title:
            list_item.setProperty('IsPlayable', 'false')
            url = '{0}?action=list_movies&gid={1}&sdata={2}&stype={3}&sort={4}&page={5}'.format(_url,gid,urllib.quote_plus(sdata),stype,sort,iurl)
            is_folder = True
        else:
            list_item.setProperty('IsPlayable', 'true')
            url = '{0}?action=play&video={1}'.format(_url, iurl)
            is_folder = False
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.setContent(_handle, 'movies')
    xbmcplugin.endOfDirectory(_handle)

    
def list_episodes(show,title,page):
    """
    Create the list of episodes in the Kodi interface.
    """
    episodes = cache.cacheFunction(get_episodes,show,title,page)
    listing = []
    for etitle,icon,iurl,labels in episodes:
        list_item = xbmcgui.ListItem(label=etitle)
        list_item.setArt(icon)
        list_item.setInfo('video', labels)
        if 'Next Page' in etitle:
            list_item.setProperty('IsPlayable', 'false')
            url = '{0}?action=list_episodes&show={1}&title={2}&page={3}'.format(_url, show, title, iurl)
            is_folder = True
            #xbmc.log('@@@@Show Nextpage = %s'%url,xbmc.LOGNOTICE)
        else:
            list_item.setProperty('IsPlayable', 'true')
            url = '{0}?action=play&video={1}'.format(_url, iurl)
            is_folder = False
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.setContent(_handle, 'episodes')
    xbmcplugin.endOfDirectory(_handle)


def play_video(vid):
    """
    Play a video by the provided video id.

    :param vid: str
    """
    # Create a playable item with a path to play.

    pk = cache.cacheFunction(get_pk)
    phdr = headers
    phdr.update({'Accept': 'application/json;pk=%s'%pk})
    url = 'https://edge.api.brightcove.com/playback/v1/accounts/5182475815001/videos/ref:%s'%vid
    r = requests.get(url, headers=headers)
    if r.status_code > 400:
        return
    jd = r.json()
    items = jd['sources']
    vid_links = []
    for item in items:
        if 'codec' in item.keys() and 'https' not in item['src']:
            vid_links.append((item['width'],item['src']))
    if len(vid_links) < 1:
        for item in items:
            if item['type'] == 'application/vnd.apple.mpegurl':
                vid_links.append(('HLS',item['src']))
    stream_url = sorted(vid_links)[0][1]
    if qual == 'HD':
        stream_url = sorted(vid_links)[-1][1]
    stream_url += '|Referer=https://www.sonyliv.com/'
    play_item = xbmcgui.ListItem(path=stream_url)
    play_item.setPath(stream_url)
    
    if subtitles:
        subs = jd['text_tracks']
        if len(subs) > 0:
            vttfile = subs[0]['src']
            play_item.setSubtitles([get_srt(vttfile)])
    
    labels = {'title': jd['name'],
              'plot': jd['description']}

    icon = {'poster': jd['thumbnail'],
           'thumb': jd['thumbnail']}
    
    play_item.setArt(icon)
    play_item.setInfo('video', labels)
        

    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)
    

def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring:
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin

    if params:
        if params['action'] == 'list_item':
            if params['item'] == 'Channels':
                list_channels()
            elif params['item'] == 'Movies':
                list_genres()
            elif params['item'] == 'Clear Cache':
                clear_cache()
        elif params['action'] == 'list_shows':
            list_shows(params['cid'],params['sdata'],params['stype'],params['sort'])
        elif params['action'] == 'list_movies':
            list_movies(params['gid'],params['sdata'],params['stype'],params['sort'],params['page'])
        elif params['action'] == 'list_episodes':
            list_episodes(params['show'],params['title'],params['page'])
        elif params['action'] == 'play':
            play_video(params['video'])
    else:
        list_top()


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])
