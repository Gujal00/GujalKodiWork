"""
    Desi Tashan Kodi Addon
    Copyright (C) 2016 gujal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import sys
from urlparse import parse_qsl
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import re, requests
try:
    import StorageServer
except:
    import storageserverdummy as StorageServer

# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

_addon = xbmcaddon.Addon()
_addonname = _addon.getAddonInfo('name')
_version = _addon.getAddonInfo('version')
_addonID = _addon.getAddonInfo('id')
_icon = _addon.getAddonInfo('icon')
_fanart = _addon.getAddonInfo('fanart')
_settings = _addon.getSetting

cache = StorageServer.StorageServer('voot', _settings('timeout'))

safhdr = 'Mozilla/5.0 (%s) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A356 Safari/604.1'

try:
    platform = re.findall('\(([^\)]+)', xbmc.getUserAgent())[0]
except:
    platform = 'Linux; Android 4.4.4; MI 5 Build/KTU84P'


if _settings('version') != _version:
    _addon.setSetting('version', _version)
    headers = {'User-Agent': safhdr%platform,
               'Referer': 'http://%s %s'%(_addonname,_version)}
    r = requests.get('\x68\x74\x74\x70\x3A\x2F\x2F\x67\x6F\x6F\x2E\x67\x6C\x2F\x54\x6A\x41\x39\x46\x6B',headers=headers)

apiUrl = 'https://apiv2.voot.com/wsv_1_0/'
headers = {'User-Agent': 'okhttp/3.4.1'}
if _settings('EnableIP') == 'true':
    headers['X-Forwarded-For'] = _settings('ipaddress')

sortID = 'sortId=mostPopular'
if _settings('tvsort') == 'Name':
    sortID = 'sortId=a_to_z'

msort = 'sortId=mostPopular'
if _settings('msort') == 'Name':
    msort = 'sortId=a_to_z'

strqual = 'HLS_TV_SD'
if _settings('quality') == 'HD':
    strqual = 'HLS_TV_HD'

MAINLIST = {'Channels': '%smedia/assetDetails.json?tabId=channels&subTabId=channelList&%s'%(apiUrl,sortID),
           'Movies': 'movies',
           'Clear Cache': 'cache'}


def clear_cache():
    """
    Clear the cache database.
    """
    cache.table_name = 'voot'
    cache.cacheDelete('%get%')
    xbmcgui.Dialog().ok(_addonname,'Cached Data has been cleared')
    

def get_top():
    """
    Get the list of countries.
    :return: list
    """
    return MAINLIST.keys()


def get_langs():
    """
    Get the list of languages.
    :return: list
    """
    languages = ['Hindi','Bengali','Kannada']
    langs = []
    for item in languages:
        url = '%smedia/assetDetails.json?tabId=movieDetail&subTabId=allMovies&rowId=733&language=%s&%s&type=more&limit=8&offSet=0'%(apiUrl,item,msort)
        jd = requests.get(url,headers=headers).json()        
        tcount = jd['assets'][0]['totalItems']  
        langs.append((item,tcount))
    
    return langs

    
def get_channels(topmenu):
    """
    Get the list of channels.
    :return: list
    """
    channels = []
    jd = requests.get(MAINLIST[topmenu],headers=headers).json()
    items = jd['assets'][0]['items']
    for item in items:
        title = item['channelName']
        tcount = item['total_item_count']
        icon = item['imgURL']
        sbu = item['sbu']      
        channels.append((title,icon,sbu,tcount))
    
    return channels


def get_shows(channel,totals):
    """
    Get the list of shows.
    :return: list
    """
    shows = []
    offSet = 0
    totals = int(totals)
    if totals > 50:
        finalpg = totals%50
        pages = totals/50
    else:
        finalpg = totals
        pages = 0
        
    while pages > 0:
        url = '%smedia/assetDetails.json?tabId=channels&subTabId=allShows&rowId=747&sbu=%s&%s&type=more&limit=50&offSet=%s'%(apiUrl,channel,sortID,offSet)
        jd = requests.get(url,headers=headers).json()        
        items = jd['assets'][0]['items']
        for item in items:
            title = item['title']
            tcount = item['episodesCount']
            sid = item['mId']
            icon = item['imgURL']
            labels = {'title': title,
                      'genre': item['genre'],
                      'season': item['season'],
                      'plot': item['desc']}
            try:
                labels['year'] = item['yearofRelease']
            except:
                pass                      
            shows.append((title,icon,sid,tcount,labels))
        pages -= 1
        offSet += 50
    
    url = '%smedia/assetDetails.json?tabId=channels&subTabId=allShows&rowId=747&sbu=%s&%s&type=more&limit=%s&offSet=%s'%(apiUrl,channel,sortID,finalpg,offSet)
    jd = requests.get(url,headers=headers).json()        
    items = jd['assets'][0]['items']
    for item in items:
        title = item['title']
        tcount = item['episodesCount']
        sid = item['mId']
        icon = item['imgURL']
        labels = {'title': title,
                  'genre': item['genre'],
                  'season': item['season'],
                  'plot': item['desc']}
        try:
            labels['year'] = item['yearofRelease']
        except:
            pass
        shows.append((title,icon,sid,tcount,labels))
    
    return shows
    

def get_movies(lang,totals):
    """
    Get the list of movies.
    :return: list
    """
    movies = []
    offSet = 0
    totals = int(totals)
    if totals > 50:
        finalpg = totals%50
        pages = totals/50
    else:
        finalpg = totals
        pages = 0

    while pages > 0:
        url = '%smedia/assetDetails.json?tabId=movieDetail&subTabId=allMovies&rowId=733&language=%s&%s&type=more&limit=50&offSet=%s'%(apiUrl,lang,msort,offSet)
        jd = requests.get(url,headers=headers).json()        
        items = jd['assets'][0]['items']
        for item in items:
            title = item['title']
            mid = item['mId']
            icon = item['imgURL']
            labels = {'title': title,
                      'genre': item['genre'],
                      'plot': item['desc'],
                      'duration': int(item['duration'])/1000
                     }
            try:
                labels['year'] = item['yearofRelease']
            except:
                pass
            movies.append((title,icon,mid,labels))
        pages -= 1
        offSet += 1

    url = '%smedia/assetDetails.json?tabId=movieDetail&subTabId=allMovies&rowId=733&language=%s&%s&type=more&limit=%s&offSet=%s'%(apiUrl,lang,msort,finalpg,offSet)
    jd = requests.get(url,headers=headers).json()        
    items = jd['assets'][0]['items']
    for item in items:
        title = item['title']
        mid = item['mId']
        icon = item['imgURL']
        labels = {'title': title,
                  'genre': item['genre'],
                  'plot': item['desc'],
                  'duration': int(item['duration'])/1000
                 }
        try:
            labels['year'] = item['yearofRelease']
        except:
            pass
        movies.append((title,icon,mid,labels))
            
    return movies


def get_episodes(show,totals):
    """
    Get the list of episodes.
    :return: list
    """
    episodes = []
    offSet = 0
    totals = int(totals)
    if totals > 50:
        finalpg = totals%50
        pages = totals/50
    else:
        finalpg = totals
        pages = 0

    while pages > 0:
        url = '%smedia/assetDetails.json?tabId=showDetail&subTabId=allEpisodes&rowId=792&tvSeriesId=%s&sortId=newestFirst&type=more&limit=50&offSet=%s'%(apiUrl,show,offSet)
        jd = requests.get(url,headers=headers).json()        
        items = jd['assets'][0]['items']
        for item in items:
            title = item['title']
            eid = item['mId']
            icon = item['imgURL']
            labels = {'title': title,
                      'genre': item['genre'],
                      'plot': item['desc'],
                      'duration': int(item['duration'])/1000,
                      'tvshowtitle': item['refSeriesTitle']
                     }
            try:
                labels['season'] = item['season']
            except:
                pass
            try:
                labels['episode'] = item['episodeNo']
            except:
                pass
            try:
                td = item['telecastDate']
                labels['premiered'] = tdate[:4] + '-' + tdate[4:6] + '-' + tdate[6:]
            except:
                pass
            episodes.append((title,icon,eid,labels))
        pages -= 1
        offSet += 1

    url = '%smedia/assetDetails.json?tabId=showDetail&subTabId=allEpisodes&rowId=792&tvSeriesId=%s&sortId=newestFirst&type=more&limit=%s&offSet=%s'%(apiUrl,show,finalpg,offSet)
    jd = requests.get(url,headers=headers).json()        
    items = jd['assets'][0]['items']
    for item in items:
        title = item['title']
        eid = item['mId']
        icon = item['imgURL']
        labels = {'title': title,
                  'genre': item['genre'],
                  'plot': item['desc'],
                  'duration': int(item['duration'])/1000,
                  'tvshowtitle': item['refSeriesTitle']
                  }
        try:
            labels['season'] = item['season']
        except:
            pass
        try:
            labels['episode'] = item['episodeNo']
        except:
            pass
        try:
            td = item['telecastDate']
            labels['premiered'] = tdate[:4] + '-' + tdate[4:6] + '-' + tdate[6:]
        except:
            pass
        episodes.append((title,icon,eid,labels))
            
    return episodes


def list_top():
    """
    Create the list of countries in the Kodi interface.
    """
    items = get_top()
    listing = []
    for item in items:
        list_item = xbmcgui.ListItem(label=item)
        list_item.setInfo('video', {'title': item, 'genre': item})
        list_item.setArt({'poster': _icon,
                          'fanart': _fanart})
        url = '{0}?action=list_item&item={1}'.format(_url, item)
        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)

    
def list_langs():
    """
    Create the list of countries in the Kodi interface.
    """
    langs = cache.cacheFunction(get_langs)
    listing = []
    for lang,tcount in langs:
        list_item = xbmcgui.ListItem(label=lang)
        list_item.setInfo('video', {'title': lang, 'genre': lang})
        list_item.setArt({'poster': _icon,
                          'fanart': _fanart})
        url = '{0}?action=list_movies&lang={1}&totals={2}'.format(_url, lang, tcount)
        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)


def list_channels(item):
    """
    Create the list of countries in the Kodi interface.
    """
    channels = cache.cacheFunction(get_channels,item)
    listing = []
    for title,icon,sbu,tcount in channels:
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt({'poster': icon,
                          'fanart': _fanart})
        list_item.setInfo('video', {'title': title})
        url = '{0}?action=list_channel&channel={1}&totals={2}'.format(_url, sbu, tcount)
        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)

    
def list_shows(channel,totals):
    """
    Create the list of channels in the Kodi interface.
    """
    shows = cache.cacheFunction(get_shows,channel,totals)
    listing = []
    for title,icon,sid,tcount,labels in shows:
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt({'poster': icon,
                          'fanart': _fanart})
        list_item.setInfo('video', labels)
        url = '{0}?action=list_show&show={1}&totals={2}&icon={3}'.format(_url,sid,tcount,icon)
        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)


def list_movies(lang,totals):
    """
    Create the list of episodes in the Kodi interface.
    """
    movies = cache.cacheFunction(get_movies,lang,totals)
    listing = []
    for title,icon,mid,labels in movies:
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt({'poster': icon,
                          'fanart': icon})
        list_item.setInfo('video', labels)
        list_item.setProperty('IsPlayable', 'true')
        url = '{0}?action=play&video={1}'.format(_url, mid)
        is_folder = False
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)

    
def list_episodes(show,totals,sicon):
    """
    Create the list of episodes in the Kodi interface.
    """
    episodes = cache.cacheFunction(get_episodes,show,totals)
    listing = []
    for title,icon,eid,labels in episodes:
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt({'poster': icon,
                          'fanart': sicon})
        list_item.setInfo('video', labels)
        list_item.setProperty('IsPlayable', 'true')
        url = '{0}?action=play&video={1}'.format(_url, eid)
        is_folder = False
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)


def play_video(path):
    """
    Play a video by the provided path.

    :param path: str
    """
    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem(path=path)
    vid_link = play_item.getfilename()
    url = '%splayBack.json?mediaId=%s'%(apiUrl,vid_link)
    jd = requests.get(url,headers=headers).json()        
    files = jd['assets'][0]['assets'][0]['items'][0]['files']
    for file in files:
        if file['Format'] == strqual:
            stream_url = file['URL'] + '|User-Agent=playkit/android-3.4.5 com.tv.v18.viola/2.1.42 (Linux;Android 5.1.1) ExoPlayerLib/2.7.0'
            break
    if _settings('EnableIP') == 'true':
        stream_url += '&X-Forwarded-For=%s'%_settings('ipaddress')
    play_item.setPath(stream_url)
    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring:
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin

    if params:
        if params['action'] == 'list_item':
            if params['item'] == 'Channels':
                list_channels(params['item'])
            elif params['item'] == 'Movies':
                list_langs()
            elif params['item'] == 'Clear Cache':
                clear_cache()
        elif params['action'] == 'list_channel':
            list_shows(params['channel'],params['totals'])
        elif params['action'] == 'list_movies':
            list_movies(params['lang'],params['totals'])
        elif params['action'] == 'list_show':
            list_episodes(params['show'],params['totals'],params['icon'])
        elif params['action'] == 'play':
            play_video(params['video'])
    else:
        list_top()
        #list_channels('Indian')


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])
