# -*- coding: utf-8 -*-
# Based on contents from https://github.com/Diecke/service.subtitles.addicted
# Thanks Diecke!

import os
import sys
import requests
import xbmcvfs
import shutil
import re
import socket
import string
import threading
from kodi_six import xbmc, xbmcplugin, xbmcgui, xbmcaddon
from six.moves import urllib_parse
from bs4 import BeautifulSoup, SoupStrainer

if hasattr(xbmcvfs, "translatePath"):
    translatePath = xbmcvfs.translatePath
else:
    translatePath = xbmc.translatePath

__addon__ = xbmcaddon.Addon()
__scriptid__ = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')
__version__ = __addon__.getAddonInfo('version')
__language__ = __addon__.getLocalizedString

__cwd__ = translatePath(__addon__.getAddonInfo('path'))
__profile__ = translatePath(__addon__.getAddonInfo('profile'))
__resource__ = translatePath(os.path.join(__cwd__, 'resources', 'lib'))
__temp__ = translatePath(os.path.join(__profile__, 'temp', ''))

sys.path.append(__resource__)

from Addic7edUtilities import log, get_language_info

self_host = "https://www.addic7ed.com"
self_release_pattern = re.compile(r"Version (.+),[^\d]+(\d+)\.(\d+)")

req_headers = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.A.B.C Safari/525.13',
               'Referer': 'https://www.addic7ed.com/'}


def get_url(url):
    response = requests.get(url, headers=req_headers)
    return response.content, response.url


def append_subtitle(sub_link):
    list_item = xbmcgui.ListItem(
        label=sub_link['lang']['name'],
        label2=sub_link['filename'])
    list_item.setArt({'icon': sub_link['rating'], 'thumb': sub_link['lang']['2let']})
    list_item.setProperty("sync", 'true' if sub_link["sync"] else 'false')
    list_item.setProperty("hearing_imp", 'true' if sub_link["hearing_imp"] else 'false')

    url = "plugin://{0}/?action=download&link={1}&filename={2}".format(__scriptid__, sub_link['link'], sub_link['filename'])
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False)


def query_tvshow(name, season, episode, languages, file_original_path):
    if season.isdigit() is not True or episode.isdigit() is not True:
        return None
    name = addic7ize(name).lower().replace(" ", "_")
    search_url = "{0}/serie/{1}/{2}/{3}/addic7ed".format(self_host, name, season, episode)
    query(search_url, languages, file_original_path)


def query_film(name, year, languages, file_original_path):
    if type(year) is not int:
        return None
    name = urllib_parse.quote(name.replace(" ", "_"))
    search_url = "{0}/film/{1}_({2})-Download".format(self_host, name, str(year))
    query(search_url, languages, file_original_path)


def query(search_url, languages, file_original_path=None):
    sub_links = []
    socket.setdefaulttimeout(20)
    # headers = req_headers
    # headers.update({'Pragma': 'no-cache'})
    content = requests.get(search_url, req_headers).text
    slink = SoupStrainer("div", {"id": "container95m"})
    tlink = SoupStrainer("span", {"class": "titulo"})
    soup = BeautifulSoup(content, "html.parser", parse_only=slink)
    title = BeautifulSoup(content, "html.parser", parse_only=tlink).text.replace("Subtitle", "").strip()
    items = soup.find_all("table", {"align": "center"})

    if file_original_path is not None:
        file_original_path_clean = file_original_path.encode('utf-8')
        file_name = str(os.path.basename(file_original_path_clean)).split("-")[-1].lower()
    else:
        file_name = None

    for item in items:
        if item.find("td", {"class": "NewsTitle"}):
            box = item.find("td", {"class": "NewsTitle"}).text
            sub_teams = self_release_pattern.match(box).groups()[0]
            full_language = item.find("td", {"class": "language"}).text.strip()

            if file_name is not None and (str(sub_teams.replace("WEB-DL-", "").lower()).find(str(file_name))) > -1:
                hashed = True
            else:
                hashed = False

            sub_language = get_language_info(full_language)
            if sub_language is None:
                sub_language = {}

            status = item.find('b').text.strip()
            link = "{0}{1}".format(self_host, item.find("a", {"class": "buttonDownload"}).get("href"))

            if len(item.find("td", {"class": "newsDate", "colspan": "2"}).find_all('img', {'title': 'Hearing Impaired'})) > 0:
                hearing_imp = True
            else:
                hearing_imp = False

            if status == "Completed" and (sub_language.get('3let', '') in languages):
                sub_links.append({'rating': '0',
                                  'filename': "{0} - {1}".format(title, sub_teams),
                                  'sync': hashed,
                                  'link': link,
                                  'lang': sub_language,
                                  'hearing_imp': hearing_imp})

    sub_links.sort(key=lambda x: [not x['sync']])
    log(__name__, "sub='{0}'".format(sub_links))

    for sub_link in sub_links:
        append_subtitle(sub_link)


def search_manual(search_string, languages):
    url = self_host + u"/search.php?search=" + search_string + u'&Submit=Search'
    content, response_url = get_url(url)

    if content is not None:
        if not response_url.startswith(self_host + u"/search.php?"):
            # A single result has been found
            query(response_url, languages)
        else:
            # A table containing several results
            soup = BeautifulSoup(content, "html.parser")
            table = soup.find('table', attrs={'class': 'tabel'})
            if table is not None:
                links = table.find_all('a')
                threads = [threading.Thread(target=query, args=(self_host + "/" + link['href'], languages))
                           for link in links]
                for t in threads:
                    t.start()
                for t in threads:
                    t.join()


def search_filename(filename):
    title, year = xbmc.getCleanMovieTitle(filename)
    log(__name__, 'clean title: "{0}" ({1})'.format(title, year))
    try:
        year_val = int(year)
    except ValueError:
        year_val = 0
    if title and year_val > 1900:
        query_film(title, year, item['3let_language'], filename)
    else:
        match = re.search(r'\WS(?P<season>\d\d)E(?P<episode>\d\d)', title, flags=re.IGNORECASE)
        if match is not None:
            tvshow = string.strip(title[:match.start('season') - 1])
            season = string.lstrip(match.group('season'), '0')
            episode = string.lstrip(match.group('episode'), '0')
            query_tvshow(tvshow, season, episode, item['3let_language'], filename)
        else:
            search_manual(filename, item['3let_language'])


def search(data):
    filename = os.path.splitext(os.path.basename(data['file_original_path']))[0]
    log(__name__, "Search_addic7ed='{0}', filename='{1}', addon_version={2}".format(data, filename, __version__))

    if data['mansearch']:
        search_manual(data['mansearchstr'], data['3let_language'])
    elif data['tvshow']:
        query_tvshow(data['tvshow'], data['season'], data['episode'], data['3let_language'], filename)
    elif data['title'] and data['year']:
        query_film(data['title'], data['year'], data['3let_language'], filename)
    else:
        search_filename(filename)


def download(link):
    subtitle_list = []

    if xbmcvfs.exists(__temp__):
        shutil.rmtree(__temp__)
    xbmcvfs.mkdirs(__temp__)

    sub_file = os.path.join(__temp__, "addic7ed.srt")

    f, _ = get_url(link)

    local_file_handle = open(sub_file, "wb")
    local_file_handle.write(f)
    local_file_handle.close()

    subtitle_list.append(sub_file)

    if len(subtitle_list) == 0:
        xbmcgui.Dialog().notification(__scriptname__, __language__(32003), "", 3000, False)

    return subtitle_list


# Sometimes search fail because Addic7ed uses URLs that does not match the TheTVDB format.
# This will probably grow to be a hardcoded collection over time.
def addic7ize(name):
    addic7ize_dict = eval(open(__cwd__ + '/addic7ed_dict.txt').read())
    return addic7ize_dict.get(name, name)


def get_params():
    param = {}
    param_string = sys.argv[2]
    if len(param_string) >= 2:
        cleaned_params = param_string.replace('?', '')
        if cleaned_params[-1] == '/':
            cleaned_params = cleaned_params[0:len(cleaned_params) - 2]
        pairs_of_params = cleaned_params.split('&')
        param = {}
        for i in range(len(pairs_of_params)):
            splitparams = pairs_of_params[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


params = get_params()

if params['action'] == 'search' or params['action'] == 'manualsearch':
    item = {'temp': False, 'rar': False, 'mansearch': False, 'year': xbmc.getInfoLabel("VideoPlayer.Year"),
            'season': xbmc.getInfoLabel("VideoPlayer.Season"),
            'episode': xbmc.getInfoLabel("VideoPlayer.Episode"),
            'tvshow': xbmc.getInfoLabel("VideoPlayer.TVshowtitle"),
            'title': xbmc.getInfoLabel("VideoPlayer.OriginalTitle"),
            'file_original_path': urllib_parse.unquote(xbmc.Player().getPlayingFile()), '3let_language': []}

    if 'searchstring' in params:
        item['mansearch'] = True
        item['mansearchstr'] = params['searchstring']

    for lang in urllib_parse.unquote(params['languages']).split(","):
        item['3let_language'].append(xbmc.convertLanguage(lang, xbmc.ISO_639_2))

    if item['title'] == "":
        item['title'] = xbmc.getInfoLabel("VideoPlayer.Title")  # no original title, get just Title

    if item['episode'].lower().find("s") > -1:  # Check if season is "Special"
        item['season'] = "0"  #
        item['episode'] = item['episode'][-1:]

    if item['file_original_path'].find("http") > -1:
        item['temp'] = True

    elif item['file_original_path'].find("rar://") > -1:
        item['rar'] = True
        item['file_original_path'] = os.path.dirname(item['file_original_path'][6:])

    elif item['file_original_path'].find("stack://") > -1:
        stackPath = item['file_original_path'].split(" , ")
        item['file_original_path'] = stackPath[0][8:]

    search(item)

elif params['action'] == 'download':
    subs = download(params["link"])
    for sub in subs:
        listItem = xbmcgui.ListItem(label=sub)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sub, listitem=listItem, isFolder=False)

xbmcplugin.endOfDirectory(int(sys.argv[1]))  # send end of directory to XBMC
