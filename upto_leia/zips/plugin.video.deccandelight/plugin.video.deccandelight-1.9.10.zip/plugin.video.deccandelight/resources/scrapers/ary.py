'''
AryDigital DeccanDelight plugin
Copyright (C) 2019 gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
from _base_ import Scraper
from BeautifulSoup import BeautifulSoup, SoupStrainer
import re
import requests
import HTMLParser


class ary(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'https://www.arydigital.tv/videos/'
        self.icon = self.ipath + 'ary.png'
        self.list = {'01Current Dramas': self.bu,
                     '02Finished Dramas': self.bu[:-7] + 'ary-digital-old-dramas/'}

    def get_menu(self):
        return (self.list, 5, self.icon)

    def get_second(self, iurl):
        """
        Get the list of shows.
        """
        shows = []
        h = HTMLParser.HTMLParser()

        html = requests.get(iurl, headers=self.hdr).text

        if 'old-dramas' in iurl:
            mlink = SoupStrainer('main', {'id': 'content'})
            mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
            items = mdiv.findAll('div', {'class': 'drama-gallery'})
        else:
            mlink = SoupStrainer('li', {'id': 'menu-item-139134'})
            mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
            items = mdiv.find('ul').findAll('li')
            shows.append(('Bulbulay Season 2', self.icon, 'https://www.arydigital.tv/videos/category/bulbulay-season-2/'))
        for item in items:
            title = h.unescape(item.text)
            url = item.find('a')['href']
            try:
                thumb = item.find('img')['data-src']
            except:
                thumb = self.icon
            shows.append((title, thumb, url))
        return (shows, 7)

    def get_items(self, url):
        h = HTMLParser.HTMLParser()
        movies = []

        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('div', {'class': re.compile('^tabs-panel')})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        plink = SoupStrainer('link', {'rel': 'next'})
        Paginator = BeautifulSoup(html, parseOnlyThese=plink)
        items = mdiv.findAll('div', {'class': re.compile('^item')})

        for item in items:
            title = h.unescape(item.h6.text).encode('utf8')
            url = item.find('a')['href']
            try:
                thumb = item.find('img')['src']
            except:
                thumb = self.icon
            movies.append((title, thumb, url))

        if len(Paginator) > 0:
            purl = Paginator.link.get('href')
            title = 'Next Page..'
            movies.append((title, self.nicon, purl))

        return (movies, 9)

    def get_video(self, url):
        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('iframe')
        videoclass = BeautifulSoup(html, parseOnlyThese=mlink)
        vidurl = videoclass.find('iframe')['src']
        return vidurl
