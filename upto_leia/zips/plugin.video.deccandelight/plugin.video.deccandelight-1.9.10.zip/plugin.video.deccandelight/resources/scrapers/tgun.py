'''
tamilgun deccandelight plugin
Copyright (C) 2016 Gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
from _base_ import Scraper
from BeautifulSoup import BeautifulSoup, SoupStrainer
import urllib
import re
import requests
import json
import HTMLParser


class tgun(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'http://tamilgun.red'
        self.icon = self.ipath + 'tgun.png'

    def get_menu(self):
        h = HTMLParser.HTMLParser()
        r = requests.get(self.bu, headers=self.hdr)
        if r.url != self.bu:
            self.bu = r.url
        items = {}
        cats = re.findall('id="menu-item-(?!4|5404|6147|13047).*?href="((?=.*categories).*?)">((?!User).*?)<', r.text)
        sno = 1
        for cat in cats:
            items['{:02d}'.format(sno) + h.unescape(cat[1]).encode('utf8')] = cat[0]
            sno += 1
        items['99[COLOR yellow]** Search **[/COLOR]'] = self.bu + '/?s='
        return (items, 7, self.icon)

    def get_items(self, url):
        h = HTMLParser.HTMLParser()
        movies = []
        if url[-3:] == '?s=':
            search_text = self.get_SearchQuery('Tamil Gun')
            search_text = urllib.quote_plus(search_text)
            url = url + search_text

        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('article', {'class': re.compile('video')})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)

        plink = SoupStrainer('ul', {'class': 'page-numbers'})
        Paginator = BeautifulSoup(html, parseOnlyThese=plink)

        for item in mdiv:
            title = h.unescape(item.h3.text).encode('utf8')
            url = item.h3.find('a')['href']
            try:
                thumb = item.find('img')['src'].strip()
            except:
                thumb = self.icon
            movies.append((title, thumb, url))

        if 'next' in str(Paginator):
            nextli = Paginator.find('a', {'class': re.compile('next')})
            purl = nextli.get('href')
            if 'http' not in purl:
                purl = self.bu[:-12] + purl
            currpg = Paginator.find('span', {'class': re.compile('current')}).text
            pages = Paginator.findAll('a', {'class': re.compile('^page')})
            lastpg = pages[len(pages) - 1].text
            title = 'Next Page.. (Currently in Page %s of %s)' % (currpg, lastpg)
            movies.append((title, self.nicon, purl))

        return (movies, 8)

    def get_videos(self, url):
        videos = []
        if 'cinebix.com' in url:
            self.resolve_media(url, videos)
            return videos

        elif 'tamildbox.' in url:
            self.resolve_media(url, videos)
            return videos

        html = requests.get(url, headers=self.hdr).text

        try:
            linkcode = urllib.unquote(re.findall(r"unescape\('([^']+)", html)[0])
            sources = re.findall('<iframe.+?src="([^"]+)', linkcode, re.IGNORECASE)
            for source in sources:
                self.resolve_media(source, videos)
        except:
            pass

        mlink = SoupStrainer('div', {'id': 'videoframe'})
        videoclass = BeautifulSoup(html, parseOnlyThese=mlink)

        try:
            links = videoclass.findAll('iframe')
            for link in links:
                url = link.get('src')
                if url.startswith('//'):
                    url = 'https:' + url
                self.resolve_media(url, videos)
        except:
            pass

        try:
            links = videoclass.findAll('a')
            for link in links:
                if 'href' in str(link):
                    url = link.get('href')
                else:
                    url = link.get('onclick').split("'")[1]
                if url.startswith('//'):
                    url = 'https:' + url
                self.resolve_media(url, videos)
        except:
            pass

        mlink = SoupStrainer('div', {'class': 'entry-excerpt'})
        videoclass = BeautifulSoup(html, parseOnlyThese=mlink)

        try:
            pdivs = videoclass.findAll('p')
            for pdiv in pdivs:
                links = pdiv.findAll('a')
                for link in links:
                    if 'href' in str(link):
                        url = link.get('href')
                    else:
                        url = link.get('onclick').split("'")[1]
                    if url.startswith('//'):
                        url = 'https:' + url
                    self.resolve_media(url, videos)
        except:
            pass

        try:
            links = videoclass.findAll('iframe')
            # self.log('Found {} iframe links'.format(len(links)))
            for link in links:
                url = link.get('src')
                if 'latest.htm' not in url:
                    # self.log(url)
                    self.resolve_media(url, videos)
        except:
            pass

        try:
            sources = json.loads(re.findall('vdf-data-json">(.*?)<', html)[0])
            url = 'https://www.youtube.com/watch?v={}'.format(sources['videos'][0]['youtubeID'])
            self.resolve_media(url, videos)
        except:
            pass

        return videos

    def get_video(self, url):
        headers = self.hdr
        headers['Referer'] = 'http://{}/'.format(self.get_vidhost(url))
        url += '&stream=1'
        html = requests.get(url, headers=self.hdr, allow_redirects=False)
        strurl = html.headers.get('location')
        return strurl
