"""
Deccandelight site plugin
Copyright (C) 2016 Gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
"""

from _base_ import Scraper
from BeautifulSoup import BeautifulSoup, SoupStrainer
import urllib
import re
import requests
import HTMLParser
import xbmcgui


class i4movie(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'http://blu-ray.me/movies-tvshows/'
        self.icon = self.ipath + 'i4movie.png'
        self.list = {'01Tamil Movies': self.bu + 'watch-letest-new-tamil-movies-online/',
                     '02Telugu Movies': self.bu + 'watch-letest-new-telugu-movies-online/',
                     '03Malayalam Movies': self.bu + 'watch-letest-new-malayalam-movies-online/',
                     '04Kannada Movies': self.bu + 'kannada/',
                     '05Hindi Movies': self.bu + 'watch-letest-new-hindi-movies-online/',
                     '06English Movies': self.bu + 'watch-letest-new-hollywood-movies-online/',
                     '07South Indian Dubbed in Hindi': self.bu + 'south-indian-hindi-dubbed/',
                     '08Hollywood Dubbed in Hindi': self.bu + 'hindi-dubbed/',
                     '09Punjabi Movies': self.bu + 'punjabi/',
                     '10Pakistan Movies': self.bu + 'pakistan/',
                     '11Bengali Movies': self.bu + 'bengali/',
                     '12Marathi Movies': self.bu + 'marathi/',
                     '98[COLOR cyan]Adult Movies[/COLOR]': self.bu + 'xxx-adult-movies/',
                     '99[COLOR yellow]** Search **[/COLOR]': self.bu[:-15] + '?s='}
 
    def get_menu(self):
        return (self.list,7,self.icon)
    
    def get_items(self,url):
        h = HTMLParser.HTMLParser()
        movies = []
        mlink = SoupStrainer('div', {'class': 'items'})
        if url[-3:] == '?s=':
            search_text = self.get_SearchQuery('India 4 Movie')
            search_text = urllib.quote_plus(search_text)
            url = url + search_text
            mlink = SoupStrainer('div', {'class': re.compile('^result')})

        html = requests.get(url, headers=self.hdr).text
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        plink = SoupStrainer('div', {'class': 'pagination'})
        Paginator = BeautifulSoup(html, parseOnlyThese=plink)
        items = mdiv.findAll('article')
        
        for item in items:
            try:
                title = h.unescape(item.h4.text).encode('utf8')
            except:
                title = h.unescape(item.find('img')['alt']).encode('utf8')
            url = item.find('a')['href']
            try:
                thumb = item.find('img')['data-lazy-src']
                if thumb.startswith('//'):
                    thumb = 'http:{}'.format(thumb)
            except:
                thumb = self.icon
            movies.append((title, thumb, url))
            
        r = re.search(r'<link\s*rel="next"\s*href="([^"]+)', html)
        
        if r:
            purl = r.group(1)
            pgtxt = Paginator.span.text
            title = 'Next Page.. (Currently in {})'.format(pgtxt)
            movies.append((title, self.nicon, purl))
        
        return (movies,8)

    def get_videos(self,url):
        videos = []
            
        html = requests.get(url, headers=self.hdr).text
        mlink = SoupStrainer('div', {'id': 'videos'})
        videoclass = BeautifulSoup(html, parseOnlyThese=mlink)

        try:
            links = videoclass.findAll('tr', {'id': re.compile('^link')})
            if len(links) > 0:
                prog_per = 0
                numlink = 0
                p_dialog = xbmcgui.DialogProgress()
                p_dialog.create('Deccan Delight', 'Processing Links...')
                for link in links:
                    eurl = link.find('a')['href']
                    vidtxt = link.find('strong', {'class': 'quality'}).text
                    epage = requests.get(eurl, headers=self.hdr, allow_redirects=False)
                    vidurl = epage.headers['Location']
                    self.resolve_media(vidurl,videos,vidtxt)
                    prog_per += 100/len(links)
                    numlink += 1
                    if p_dialog.iscanceled():
                        return videos
                    p_dialog.update(prog_per, 'Processed Links... {} of {}'.format(numlink, len(links)))
        except:
            pass

        try:
            mlink = SoupStrainer('div', {'class': 'dooplay_player'})
            videoclass = BeautifulSoup(html, parseOnlyThese=mlink)
            links = videoclass.findAll('li', {'id': re.compile(r'^player-option-\d')})
            if len(links) > 0:
                ajaxurl = self.bu[:-16] + '/wp-admin/admin-ajax.php'
                headers = self.hdr
                headers['Referer'] = url
                prog_per = 0
                numlink = 0
                p_dialog = xbmcgui.DialogProgress()
                p_dialog.create('Deccan Delight', 'Processing Links...')
                for link in links:
                    post = link.get('data-post')
                    nume = link.get('data-nume')
                    ptype = link.get('data-type')
                    vidtxt = link.find('span', {'class': 'title'}).text
                    data = {'action': 'doo_player_ajax',
                            'post': post,
                            'nume': nume,
                            'type': ptype}
                    ahtml = requests.post(ajaxurl, data=data, headers=headers).text
                    vidurl = re.findall('''<iframe.+?src=['"]([^'"]+)''', ahtml)[0]
                    self.resolve_media(vidurl,videos,vidtxt)
                    prog_per += 100/len(links)
                    numlink += 1
                    if p_dialog.iscanceled():
                        return videos
                    p_dialog.update(prog_per, 'Processed Links... {} of {}'.format(numlink, len(links)))           
        except:
            pass

        return videos
