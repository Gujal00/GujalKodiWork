'''
bigbosstamil deccandelight plugin
Copyright (C) 2018 Gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''

from _base_ import Scraper
from BeautifulSoup import BeautifulSoup, SoupStrainer
import urllib
import re
import requests
from resources.lib import cfscrape
import HTMLParser

try:
    import StorageServer
except:
    import storageserverdummy as StorageServer
cache = StorageServer.StorageServer('deccandelight', 1)


class bbt(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'https://bigtamilboss.net/'
        self.icon = self.ipath + 'bbt.png'

    def get_cf(self):
        cj = cfscrape.get_tokens(self.bu, user_agent=self.hdr['User-Agent'])[0]
        ckstr = '; '.join([str(x) + "=" + str(y) for x, y in cj.items()])
        return (cj, ckstr)

    def get_menu(self):
        cj = cache.cacheFunction(self.get_cf)[0]
        html = requests.get(self.bu, headers=self.hdr, cookies=cj).text
        mlink = SoupStrainer('nav', {'id': 'main-navigation'})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        items = mdiv.findAll('li', {'id': re.compile(r'menu-item-[23]\d+')})
        mlist = {}
        ino = 1
        for item in items:
            mlist.update({'{0:02d}{1}'.format(ino, item.text): item.find('a').get('href')})
            ino += 1
        mlist.update({'99[COLOR yellow]** Search **[/COLOR]': '{0}?s=MMMM7'.format(self.bu)})
        return (mlist, 7, self.icon)

    def get_items(self, url):
        cj, ckstr = cache.cacheFunction(self.get_cf)
        h = HTMLParser.HTMLParser()
        movies = []
        if url[-3:] == '?s=':
            search_text = self.get_SearchQuery('BigBoss Tamil')
            search_text = urllib.quote_plus(search_text)
            url = url + search_text

        html = requests.get(url, headers=self.hdr, cookies=cj).text
        mlink = SoupStrainer('div', {'id': 'content'})
        plink = SoupStrainer('div', {'class': 'nav-links'})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        items = mdiv.findAll('article')
        Paginator = BeautifulSoup(html, parseOnlyThese=plink)
        for item in items:
            title = h.unescape(item.h2.text).encode('utf8')
            # title = self.clean_title(title)
            url = item.find('a')['href']
            if item.find('img'):
                thumb = item.find('img')['src'] + '|User-Agent={}&Cookie={}'.format(self.hdr['User-Agent'], ckstr)
            else:
                thumb = self.icon
            movies.append((title, thumb, url))

        if 'next' in Paginator.text.lower():
            purl = Paginator.find('a', {'class': re.compile('^next')}).get('href')
            currpg = Paginator.find('span', {'class': re.compile('current')}).text
            lastpg = Paginator.findAll('a', {'class': 'page-numbers'})[-1].text
            title = 'Next Page.. (Currently in Page {} of {})'.format(currpg, lastpg)
            movies.append((title, self.nicon, purl))

        return (movies, 8)

    def get_videos(self, url):
        cj = cache.cacheFunction(self.get_cf)[0]
        videos = []

        html = requests.get(url, headers=self.hdr, cookies=cj).text
        mlink = SoupStrainer('iframe')
        links = BeautifulSoup(html, parseOnlyThese=mlink)

        try:
            for link in links:
                vidurl = link.get('src')
                self.resolve_media(vidurl, videos)
        except:
            pass

        return videos
