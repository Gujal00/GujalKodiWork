'''
yaartv deccandelight plugin
Copyright (C) 2018 Gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
from _base_ import Scraper
from BeautifulSoup import BeautifulSoup, SoupStrainer
import re
import requests
import HTMLParser
import xbmcgui


class apnetv(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'https://apnetv.co/Hindi-Serials'
        self.icon = self.ipath + 'apnetv.png'

    def get_menu(self):
        mlist = {}
        html = requests.get(self.bu, headers=self.hdr).text
        mlink = SoupStrainer('ul', {'class': 'tabs'})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        items = mdiv.findAll('li')
        ino = 1
        for item in items:
            mlist['{:02d}{}'.format(ino, item.text)] = item.find('a')['href']
            ino += 1
        return (mlist, 5, self.icon)

    def get_second(self, iurl):
        """
        Get the list of shows.
        :return: list
        """
        shows = []
        h = HTMLParser.HTMLParser()

        html = requests.get(self.bu, headers=self.hdr).text
        mlink = SoupStrainer('div', {'id': iurl[1:]})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        items = mdiv.findAll('li')
        for item in items:
            title = h.unescape(item.find('a').text)
            url = item.find('a').get('href')
            shows.append((title.encode('utf8'), self.icon, url.encode('utf8')))

        return (shows, 7)

    def get_items(self, iurl):
        episodes = []
        html = requests.get(iurl, headers=self.hdr).text
        mlink = SoupStrainer('div', {'class': 'latest-pisode-list'})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        items = mdiv.findAll('div', {'class': re.compile('^s-epidode')})
        for item in items:
            try:
                title = item.find('div', {'class': 'epi-name'}).text
                tdiv = item.find('figure')['style']
                thumb = re.findall("'([^']+)", tdiv)[0]
                url = item.a['href']
                episodes.append((title, thumb, url))
            except:
                pass

        plink = SoupStrainer('div', {'class': 'pagination_btns'})
        Paginator = BeautifulSoup(html, parseOnlyThese=plink)
        if 'Next' in str(Paginator):
            nlinks = Paginator.findAll('a', {'class': 'prev_next_btns'})
            iurl = nlinks[-2].get('href')
            currpg = Paginator.find('a', {'class': re.compile('^page_active')}).text
            lastpg = nlinks[-1].get('href').split('/')[-1]
            title = 'Next Page.. (Currently in Page {0} of {1})'.format(currpg, lastpg)
            episodes.append((title, self.nicon, iurl))

        return (episodes, 8)

    def get_videos(self, iurl):
        videos = []
        html = requests.get(iurl, headers=self.hdr).text
        mlink = SoupStrainer('div', {'class': 'bottom_episode_list'})
        mdiv = BeautifulSoup(html, parseOnlyThese=mlink)
        items = mdiv.findAll('li')
        prog_per = 0
        numlink = 0
        pDialog = xbmcgui.DialogProgress()
        pDialog.create('Deccan Delight', 'Processing Links...')
        for item in items:
            vid_link = item.find('a')['href'] + '|Referer=' + self.bu
            self.resolve_media(vid_link, videos)
            prog_per += 100 / len(items)
            numlink += 1
            if (pDialog.iscanceled()):
                return videos
            pDialog.update(prog_per, 'Collected Links... {} from {}'.format(len(videos), len(items)))
        return videos
